const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
module.exports = {
        mode: 'production',
        entry: './lib/core.js',
        output: {
            path: path.resolve(__dirname, './dist'),
            filename: 'wa.min.js',
            library: 'wa',
            libraryTarget: 'umd',
            globalObject: 'this',
            libraryExport: 'default'
        },
        module: {
            rules: [
                {
                    test: /\.(js)$/,
                    exclude: /(node_modules|bower_components)/,
                    use: 'babel-loader'
                }
            ]
        },
        plugins: [
            new UglifyJsPlugin({
                uglifyOptions: {
                    minimize: true,
                    sourceMap: false,
                    mangle: {
                        toplevel: true,
                    },
                    output: {
                        comments: false
                    },
                    compressor: {
                        warnings: false,
                        booleans: true,
                        dead_code: true,
                    }
                }
              }),
        ]
    }
