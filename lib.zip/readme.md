
# WelabAnalytics
ARMS, Analytics SDK.

## 用处

WelabAnalytics 
1. 标识唯一设备id, 是在浏览器的cookie里插入一个特定的值供服务器来使用.
2. track 用户的行为.
3. 上报运行时异常.

## 使用及开发文档
启动.
```javascript
  > npm install
  > node server
```
生产环境
```shell
  > npm run build:browser
```

- 0. 初始化可配置.


Welab Anaylstic 初始化可以传入配置对象,来制定可以加载的最新sdk文件, 全局命名空间, 日志上报接口地址等。
格式如下

```javascript
// 同步载入方式
<script type='text/javascript'>
                    // document.getElementById('root').innerHTML = "cookie测试地址" + window.cookieValue;
                    (function(param) {
                        var n = param.namespace;
                        window['WelabAnalyticsObject'] = n;
                        window[n] = {
                            _q: [],
                            para: param,
                        }
                        window[n].l = 1 * new Date();
                        })({
                            heatmap_url: '',
                            namespace: 'wa',
                            web_url: '',
                            server_url: 'https://japi-dev.wolaidai.com/welab-skyeye/v1/collector',
                            heatmap: {
                                collect_element: function(element_target){
                                    console.log('element_target', element_target);
                                    // 如果这个元素有属性sensors-disable=true时候，不采集
                                    if(element_target.getAttribute('sensors-disable') === 'true'){
                                        return false;
                                    }else{
                                        return true;
                                    }
                                },
                                clickmap:'default',
                            },
                            is_spa: true,
                      })
               </script>
               <script src="./wa.js"></script>
               <script>
                   wa.quick('autoTrack');
               </script>
```

```javascript
// 异步载入方式
<script type='text/javascript'>
                    // document.getElementById('root').innerHTML = "cookie测试地址" + window.cookieValue;
                    (function(param) {
                        var n = param.namespace;
                        window['WelabAnalyticsObject'] = n;
                        window[n] = {
                            _q: [],
                            para: param,
                        }
                        window[n].l = 1 * new Date();
                        var a = document.createElement('script');
                        var m = document.getElementsByTagName('script')[0];
                        a.async = 0;
                        a.src = param.sdk_url;
                        m.parentNode.insertBefore(a,m);
                        })({
                            // sdk_url: './wa.js',
                            heatmap_url: '',
                            namespace: 'wa',
                            web_url: '',
                            server_url: 'https://japi-dev.wolaidai.com/welab-skyeye/v1/collector',
                            heatmap: {
                                collect_element: function(element_target){
                                    console.log('element_target', element_target);
                                    // 如果这个元素有属性sensors-disable=true时候，不采集
                                    if(element_target.getAttribute('sensors-disable') === 'true'){
                                        return false;
                                    }else{
                                        return true;
                                    }
                                },
                                clickmap:'default',
                            },
                            is_spa: true,
                      })
        
                      console.log(wa, wa.quick);
               </script>
               <script>
                   wa.quick('autoTrack');
               </script>
```

- 1. ajax, fetch 代理.
  ajax, fetch 强制覆盖原生对象, 客户端调用的都是我们的代理ajax, fetch对象. 

- 2. cookie 
  canvase 指纹 + 时间戳 + 随机数.

- 3. 前端指标. 
   - ua
   - ...
   - screen_width.

- 4. 热点图, click 点击事件上报.heatmap. 
 神策的一个热点图中dom结构可以看到是这样的.
 <iframe frameborder="0" width="100%" style="height: 2639px;" data-url="https://heatmap.sensorsdata.cn/financedemo/index.html" src="https://heatmap.sensorsdata.cn/financedemo/index.html?sa-request-id=54dd5ed9-124b-443f-984e-77c9734e75fd&amp;sa-request-url=https%3A%2F%2Ffinancedemo.cloud.sensorsdata.cn%2F%3Fproject%3Ddefault"></iframe>

## 逻辑,   (应用的version ???)
- 1 : MarkId 是否有，如果没有，客户端的环境信息传到服务器。 浏览器UA等信息。
- 2 ：location.href, <button>, <input>, <a> 绑定Class标识.
- 3 : 定时异步上传到服务端. 参数要带MarkId.
- 4 : onError 捕捉。 onError,  放入头部，才能捕捉事件.
- 5 : 热点图, 热点图和应用之间的关系是? ,热点图是否是在后端模式才可以开启? 如果不是,那么热点图js就可以进入应用模式吗?
    
- 4 : 应用手机模拟器, 真实的， heatmap. 

sd.para.heatmap.collect_elements === 'all'

## 指标
页面打开速度（测速） 页面稳定性（JS Error） 外部服务调用成功率（API）

系统固定指标:


系统可变指标-页面打开速度：
---
1. dns : DNS 解析耗时, domainLookupEnd - domainLookupStart,
2. tcp : TCP 连接耗时, connectEnd  - connectStart
3. ttfb: Time to First Byte（TTFB），网络请求耗时, responseStart - requestStart  ARMS 以 Google Development 定义为准
4. trans: 数据传输耗时, responseEnd - responseStart
5. dom: DOM 解析耗时	domInteractive - responseEnd
6. res: 资源加载耗时	loadEventStart - domContentLoadedEventEnd	表示页面中的同步加载资源

- firstbyte	首包时间	responseStart - domainLookupStart	
- fpt	First Paint Time, 首次渲染时间 / 白屏时间	responseEnd - fetchStart	从请求开始到浏览器开始解析第一批 HTML 文档字节的时间差
- tti	Time to Interact，首次可交互时间	domInteractive - fetchStart	浏览器完成所有 HTML 解析并且完成 DOM 构建，此时浏览器开始加载资源
- ready	HTML 加载完成时间， 即 DOM Ready 时间	domContentLoadEventEnd - fetchStart	如果页面有同步执行的 JS，则同步 JS 执行时间 = ready - tti
- load	页面完全加载时间	loadEventStart - fetchStart	load = 首次渲染时间 + DOM 解析耗时 + 同步 JS 执行 + 资源加载耗时

用户行为指标:
<img src="http://docs-aliyun.cn-hangzhou.oss.aliyun-inc.com/assets/pic/60288/cn_zh/1519980972409/timing-overview-large_mini.png">


## 参考资源
1. https://help.aliyun.com/document_detail/60288.html?spm=a2c4g.11186623.6.571.703p0A
2. [performance 标准](https://www.w3.org/TR/navigation-timing/?spm=a2c4g.11186623.2.7.MWl1t4)
3. http://www.stevesouders.com/blog/2012/10/30/qa-nav-timing-and-post-onload-requests/
4. https://caniuse.com/#feat=nav-timing


## TODO:
1. uuid中间的时间 直接用时间戳.