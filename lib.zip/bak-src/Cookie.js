/**
 * 生成设备ID, 并将设备ID 放入Cookie里.
 * 
 * 
 */

import Util from './Util';
import Config from './Config';
import { set, get } from 'js-cookie';

const Cookie = function () {
  const key = Config.key;
  const domains = Config.domain;
  const current_domain = window.location.host.match(/\w*\.com/g);
  const cid = get(key);
  if (!cid) {
      const uuids = Util.uuid();
      // 对于PNG文件格式，以块(chunk)划分，最后一块是一段32位的CRC校验
      const canvasFingerValue = Util.canvasFinger();
      for (var i = 0; i < domains.length; i++) {
          set(key, canvasFingerValue + "." + uuids[0] + '.' + uuids[1] , {
              domain: domains[i],
              expires: 365 * 1000
          });
      }
  } else {
      window.xMarkID = cid;
  }
}

export default Cookie;
