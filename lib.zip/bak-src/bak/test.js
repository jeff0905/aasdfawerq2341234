import {
  hook
} from './bak/ajax';
import $ from 'jquery';

hook();

/**
 * 测试的情况
 * 1. 跨域
 *    1.1 设置了credentials = false,
 *    1.2 设置了credentials = true,
 * 2. 不跨域
 *    2.1 设置了credentials = false,
 *    2.2 设置了credentials = true.
 * 
 * 结果:
 * 1. 跨域
 *    1.1 设置了credentials = false,
 *      带Cookie了.
 *    1.2 设置了credentials = true,
 */
const ajaxTest = function() {
    console.log('ajaxTest init........');
    $.get('https://japi-dev.wolaidai.com/welab-skyeye/v1/detail?beginTime=2018-07-04+09:59:49&endTime=2018-07-04+13:59:49&metricGroup=app.druid.active.count&interval=1h')
      .then(res => {console.log('......ajaxTest res ......', res)});
}

const fetchTest = function() {
  // fetch('https://japi-dev.wolaidai.com/welab-skyeye/v1/detail?beginTime=2018-07-04+00:00:00&endTime=2018-07-04+17:32:22&app=loan-procedure&metricGroup=app.error&interval=1h');
}


ajaxTest();