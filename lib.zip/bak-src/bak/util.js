/**
 * 工具类.
 * 
 * 
 */

const Util = {
  namespace: 'wca',
  /**
   * 每个机器给予唯一的值,
   * 规则:
   *   [time]_[random]_[ua]_[width*height]_[domain]_[]
   */
  uuid: function () {
    const uuid_time = function () {
      const d = 1 * new Date();
      let i = 0;
      while (d === 1 * new Date()) {
        i++;
      }
      return d.toString(16) + i.toString(16);
    }

    const uuid_random = function () {
      return Math.random().toString(16).replace('.', '');
    }
    return [uuid_time(), uuid_random()];
  },

  /**
   * Canvas (https://www.browserleaks.com/canvas)
   * 相同的HTML5 Canvas元素绘制操作，在不同操作系统、不同浏览器上，产生的图片内容不完全相同。
   * 在图片格式上，不同浏览器使用了不同的图形处理引擎、不同的图片导出选项、不同的默认压缩级别等。
   * 在像素级别来看，操作系统各自使用了不同的设置和算法来进行抗锯齿和子像素渲染操作。即使相同的绘图操作，产生的图片数据的CRC检验也不相同。
   */
  canvasFinger: function () {
    if (Util.isCanvaseSupport) {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const text = 'welab';
      ctx.font = "14px 'Arial'";
      ctx.fillStyle = "#f60";
      ctx.fillRect(125, 1, 62, 20);
      ctx.fillStyle = '#069';
      ctx.fillText(text, 2, 15);
      ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
      ctx.fillText(text, 4, 17);
      const base64 = canvas.toDataURL().replace('data:image/png;base64,', '');
      const bin = atob(base64);
      const crc = Util.bin2Hex(bin.slice(-16, -12));
      console.log('crc', crc);
      return crc;
    } else {
      return '';
    }
  },

  bin2Hex: function (s) {
    let i
    let l
    let o = ''
    let n
    s += "";
    for (i = 0, l = s.length; i < l; i++) {
      n = s.charCodeAt(i).toString(16)
      o += n.length < 2 ? '0' + n : n
    }
    return o
  },

  isCanvaseSupport: function () {
    const elem = document.createElement('canvas');
    return !!(elem.getContext && elem.getContext('2d'));
  },

  /**
   * 浏览器的信息
   * 硬件类型 操作系统 用户代理 系统字体 语言 屏幕分辨率 浏览器插件 浏览器扩展 浏览器设置 时区差 有很大的冲突概率，只能作为辅助识别(https://www.whatismybrowser.com/)
   */
  browser: function () {
    const keys = [];
    const navigator = window.navigator;
    keys.push(navigator.platform || '');
    keys.push(navigator.cpuClass || '');
    keys.push(navigator.userAgent || '');
  }

}

export default Util;
