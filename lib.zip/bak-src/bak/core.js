/**
 * The main WA namespace..
 * 
 */
const WA = function () {
  this.version = 'v1.0.0';
  this.namespace = 'wa';
  this.model = {
    $xMarkId: '', // 设备ID.
    $time: new Date().getTime(), // 访问时间, 开始进入的时间. 
    $is_first_day: false, // 是否首日.
    $ip: '',
    $city: '',
    $province: '',
    $country: '',
    $manufacturer: '', // 设备制造商.
    $model: '', // 设备型号.
    $os: '', // 操作系统
    $os_v: '', // 操作系统版本号.
    $s_height: window.screen.height || '获取不到高度', // 屏幕高度.
    $s_width: window.screen.width || '获取不到宽度', // 屏幕宽度.
    $wifi: '', // 是否WIFI.
    
    $href: window.location.href, // 页面地址.
    $title: window.document.title, // 页面标题.
  }
}

export default WA;
