/**
 * 
 * Copyright 2014 Welab Inc. All Rights Reserved.
 * 
 * This is the sdk for Welab Analytics 
 **/

/*
 * @author: Jeff.lv --
 * @date: 2018-07-03 --
 * @version: 1.0.0 --
 * =====================
 * 用户访问之后, 设置cookie, 后续所有的请求带上该cookie。 N个用户的cookie值 是不一样的，附带可以区别出是否是同一台设备
 * 首次访问, 首日, 已经访问过,
 * 
 * Topic: 
 * 1. 识别不同设备，降低碰撞率(两个不同的设备，uuid一样).
 * 
 * # 参考资源
 * 1. https://github.com/saijs/sai.js/blob/master/sai.js
 */

import {
    get,
    set
} from 'js-cookie';

import Config from './config';
import Util from './util';
import { hook } from './ajax';
// import './test';

;(function (window, namespace) {
    //TODO:
    window[Config.namespace] = namespace;
    window[namespace] = window[namespace] || function() {

    }
    if (typeof wca !== 'function' || typeof wca !== 'object' || typeof wca !== 'string') {
        const wca = {}
        wca.namespace = "wca";
        wca.model = {
            $xMarkId: '', // 设备ID.
            $time: new Date().getTime(), // 访问时间, 开始进入的时间. 
            $is_first_day: false, // 是否首日.
            $ip: '',
            $city: '',
            $province: '',
            $country: '',
            $manufacturer: '', // 设备制造商.
            $model: '', // 设备型号.
            $os: '', // 操作系统
            $os_v: '', // 操作系统版本号.
            $s_height: window.screen.height || '获取不到高度', // 屏幕高度.
            $s_width: window.screen.width || '获取不到宽度', // 屏幕宽度.
            $wifi: '', // 是否WIFI.
            
            $href: window.location.href, // 页面地址.
            $title: window.document.title, // 页面标题.
        }
        // 事件
        wca.event = {
            // 添加事件.
            on: function (element, event, handler, useCapture = false) {
                if (element.addEventListener) {
                    element.addEventListener(event, handler, useCapture);
                } else if (element.attachEvent) {
                    element.attachEvent(`on${event}`, handler);
                } else {
                    element[`on${event}`] = handler;
                }
            },
    
            // 移除事件.
            off: function (element, event, handler, useCapture = false) {
                if (element.removeEventListener) {
                    element.removeEventListener(event, handler, useCapture);
                } else if (element.detachEvent) {
                    element.detachEvent(`on${event}`, handler);
                } else {
                    element[`on${event}`] = null;
                }
            },
    
            // 阻止默认事件.
            preventDefault: function (event) {
                if (event.preventDefault) {
                    event.preventDefault();
                } else {
                    event.returnValue = false;
                }
            },
    
            // 阻止事件流或使用 cancelBubble
            stopPropagation: function () {
                if (event.stopPropagation) {
                    event.stopPropagation();
                } else {
                    event.cancelBubble = true;
                }
            }
        }
    
        /**
         * cookie 操作.
         * @argument {String} key 插入cookie的key值.
         * @argument {String} domain 插入cookie的domain值, 可以是数组,
         * 
         */
        wca.cookie = {
            init: function () {
                const key = Config.key || 'X-Mark-Id';
                const domains = Config.domain || ['.wolaidai.com', '.wolaidai.cn'];
                const current_domain = window.location.host.match(/\w*\.com/g);
                const cid = get(key);
                if (!cid) {
                    const uuids = Util.uuid();
                    // 对于PNG文件格式，以块(chunk)划分，最后一块是一段32位的CRC校验
                    const canvasFingerValue = Util.canvasFinger();
                    for (var i = 0; i < domains.length; i++) {
                        set(key, canvasFingerValue + "." + uuids[0] + '.' + uuids[1] , {
                            domain: domains[i],
                            expires: 365 * 1000
                        });
                    }
                } else {
                    window.xMarkID = cid;
                }
            }
        };
    
        /**
         * 异常上报
         * 
         */
        wca.error = {
            /**
             * 捕捉所有异常信息的函数.
             * 1. 运行时错误.
             * 2. 404 错误 
             *    not.
             * 3. 异步错误, (error信息2部分, 1部分promise, 1部分reason)
             *    (Promise.reject):  ok
             * 4. 语法错误捕获不了.
             * 
             * 浏览器兼容性:
             * 1. IE10以下只有行号，没有列号， 
             * 2. IE10有行号列号，但无堆栈信息。
             * 3. IOS下onerror表现非常统一，包含所有标准信息
             * 4. 安卓部分机型没有堆栈信息
             * 
             * @param {String} errorMessage   错误信息
             * @param {String} scriptURI      出错文件
             * @param {Long}   lineNumber     出错的行号
             * @param {Long}   columnNumber   出错代码的列号
             * @param {Object} errorObj       错误的详细信息
             */
            errorHandler: function (error) {
                const params = [];
                // in the chrome, error is object, include message, filename, lineno, colno, error.
                if (error.message && error.lineno) {
                    params.push(error.message || '');
                    params.push(error.filename || '');
                    params.push(error.lineno || '');
                    params.push(error.colno || '');
                    params.push(error.error || '');
                }
                try {
                    // 暂时上报字符信息，格式后续再改.
                    new Image().src = `${Config.url}?data=${params.toString()}`;
                } catch (e) {
                    // nothing to do.  我们只想发出去， 不想获取结果怎么样.
                }
    
                return true;
            },
    
            init: function () {
                wca.event.on(window, 'error', wca.error.errorHandler, true);
                wca.event.on(window, 'unhandledrejection', wca.error.errorHandler, true);
            }
        }
        /**
         * ajax 强制跨域带cookie.
         * 
         */
        wca.forceCookie = function () {
            hook();
        }
    
        /**
         * Outputs extended measurements using Navigation Timing API
         * @return Object 
         */
        wca.indicator = function() {
            // performance timing..
            var performance = window.performance || window.webkitPerformance || window.msPerformance || window.mozPerformance;
            
            if (performance === undefined) {
                return false;
            }
            var timing = performance.timing;
            var in_per = {
                dns: timing.domainLookupEnd  - timing.domainLookupStart,  //  DNS 解析耗时
                tcp: timing.connectEnd  - timing.connectStart,            // TCP 连接耗时
                ttfb: timing.responseStart  - timing.requestStart,        // 网络请求耗时
                dom: timing.domInteractive  - timing.responseEnd,         // DOM 解析耗时
                res: timing.loadEventStart  - timing.domContentLoadedEventEnd,   // 资源加载耗时
                firstbyte: timing.responseStart  - timing.domainLookupStart, // 首包时间
                fpt: timing.responseEnd  - timing.fetchStart, // 首次渲染时间 / 白屏时间
                tti: timing.domInteractive  - timing.fetchStart, // 首次可交互时间
                ready: timing.domContentLoadEventEnd  - timing.fetchStart, // HTML 加载完成时间
                load: timing.loadEventStart  - timing.fetchStart,  // 页面完全加载时间
            }
            console.log('时间', in_per);
        }

        /**
         * 初始化时间
         * 
         */
        wca.init = function () {
            wca.forceCookie();
            wca.cookie.init();
            wca.error.init();

            wca.indicator();
            if (window.fetch) {
                const fetchWrapper = window.fetch;
                window.fetch = (function (fetch) {
                    return function (url, option) {
                      if (!option) {
                          option = {};
                          option.credentials = 'include';
                      } else {
                          option.credentials = 'include';
                      }
                      return fetch(url, option)
                    };
                })(window.fetch);
            }
            wca.indicator();
        }
        // 执行初始化...
        wca.init();
        window.wca = wca;
    }
})(window, 'bb');

