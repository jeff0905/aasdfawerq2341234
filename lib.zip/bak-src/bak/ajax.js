/**
 * ajax 请求的方法.
 * 1: 全局设置所有ajax的属性.
 * 2: ajax请求的封装.
 * 
 */

/**
 * ajax 原生的创建方法.
 * 
 */
const xhr = function () {
  if (XMLHttpRequest) {
    return new XMLHttpRequest();
  }
  if (window.ActiveXObject) {
    try {
      return new ActiveXObject('Msxml2.XMLHTTP')
    } catch (d) {
      try {
        return new ActiveXObject('Microsoft.XMLHTTP')
      } catch (d) {}
    }
  }
}

const api = function (param) {
  const ajax = xhr();

  if (!param.type) {
    param.type = param.data ? 'POST' : 'GET';
  }

  ajax.onreadystatechange = function () {
    if (ajax.readyState == 4) {
      if (ajax.status >= 200 && ajax.status < 300 || ajax.status  == 304) {
        param.success(ajax.responseText);
      } else {
        param.fail(ajax.responseText, g.status);
      }
      ajax.onreadystatechange = null;
      ajax.onload = null;
    }
  }

  ajax.open(param.type, param.url, true);
  ajax.send(param.data || null);
}

const hook = function () {
  const ah=require("ajax-hook")
  ah.hookAjax({
    //hook function
    send:function(arg,xhr){
      xhr.withCredentials = true;
    }
  })
}

export {
  api,
  hook,
  xhr,
}