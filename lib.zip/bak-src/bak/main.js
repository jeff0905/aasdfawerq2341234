const WA = require('./core');

WA.init();

