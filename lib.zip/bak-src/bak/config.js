export default {
  version: '1.0.0',
  namespace: 'WelabAnalyticsObject',
  url: 'https://japi-dev.wolaidai.com/welab-skyeye/v1/collector',
  key: 'X-Mark-Id',
  domain: ['.wolaidai.com', '.wolaidai.cn']
}