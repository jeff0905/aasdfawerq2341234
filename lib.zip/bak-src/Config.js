export default {
  version: '1.0.0',
  namespace: 'WelabAnalyticsObject',
  url: 'https://japi-dev.wolaidai.com/welab-skyeye/v1/collector',
  key: 'X-Mark-Id',
  domain: ['.wolaidai.com', '.wolaidai.cn'],
  trackEle: ['a', 'button', 'input', 'textarea'], // 要搜集的元素.
  eventType: ['$PageView', '$WebClick', '$WebStay'], // 事件类型, PageView 页面浏览, WebClick点击元素, $WebStay, 停留.
}