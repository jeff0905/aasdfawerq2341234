/**
 * 用户跟踪的方法.
 * 
 * 
 */
import Config from './Config';
import Util from './Util';
import { api } from './Ajax';

const Track = function () {
  
  const init = function () {
    console.log('Track init');
    Util.event.on(document, 'click', documentClickHandler, false);
  }

  const documentClickHandler = function (e) {
    console.log('document, click , ', e);
    var event = e || window.event;
    if (!event) {
      return false;
    }
    var target = event.target || event.srcElement;
    var tagName = target.tagName; 
    if (!Util.isString(tagName)) {
      return false;
    }
    console.log(target, tagName, target.parentNode);

    start(event, target, tagName);
  }

  /**
   * 启动事件.
   * 
   * @param {*} event 
   * @param {*} target 
   * @param {*} tagName 
   */
  const start = function(event, target, tagName) {
    var props = getEleInfo(target);
    console.log('启动事件', props);
    api({
      url: Config.url,
      type: 'POST',
      data: JSON.stringify(props),
      success: function(data) {
        console.log('data', data);
      },
      fail: function(error) {
        console.log('error', error);
      }
    })
  }

  /**
   * 获取DOM元素的属性.
   * 
   * @param {*} ele 
   * @return {*} props 
   */
  const getEleInfo = function (ele) {
    console.log('获取DOM元素', ele);
    var props = {};
    props.$element_type = ele.tagName;
    props.$element_name = ele.getAttribute('name');
    props.$element_id = ele.getAttribute('id');
    props.$element_class_name = typeof ele.className === 'string' ? ele.className : null;
    props.$element_target_url = ele.getAttribute('href');
    props.$url = location.href;
    props.$url_path = location.pathname;
    props.$title = document.title;
    var textContent = '';
    // 文案....
    if (ele.textContent) {
      textContent = ele.textContent;
    } else if (ele.innerText) {
      textContent = ele.innerText;
    } else if (ele.placeholder) {
      textContent = ele.placeholder;
    }
    props.$element_content = textContent || '';
    return props;
  }

  const startTrack = function(type, props) {

  }
  return {
    init,
  }
}

export default Track;
