1. 事件模型

## 1.1 异常数据.
```javascript
{
    // 设备Id
    "x_mark_id": "2b0a6f51a3cd6775", 
    // 发生的时间
    "time": 1434556935000,
    // 数据类型, 用户行为跟踪, 异常跟踪
    "type": "track" || "error",
    // 发生的事件
    "event": "PageView" || "error" || "action",
    // 值. 发生了什么
    "properties": { 
        "$ip" : "180.79.35.65",
        "user_gent" : "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.）",
        "page_name" : "网站首页",
        "url" : "www.demo.com",
        "referer" : "www.referer.com"
    }    
}
```

## 1.0 收集指标.
