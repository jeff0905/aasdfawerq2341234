// import Core from './Core';
// import Cookie from './Cookie';
// import Util from './Util';

// const core = new Core();
// console.log('model,', core);
// var model = core.model;
// // 1. 插入Cookie...
// Cookie();

// // 2. 插入javascript...
// Util().loadScripts('http://saas-dev.wolaidai.com/skyeye/index.128a5bbc.js', function() {
//   console.log('加载完成');
// });
import Cookie from './Cookie';
import UA from './Ua';
import Util from './Util';
import Track from './Track';
console.log('引入了index.js');
;(function(window, document, s, u, wa) {

  window['WelabAnalyticsObject'] = wa;
  console.log('执行了匿名函数');
  window[wa] = window[wa] || function () {
    console.log('this对象是', this);
    // 1. 种Cookie.
    Cookie();

    // . 获取browser, os, engine等信息.
    const getUA = function () {
      return UA;
    }

    // 2. track.
    const track = new Track();
    track.init();

    const performance = Util.getPerformance();
    console.log('performance', performance);
    
    return {
      getUA,
    }
  }
})(window, document, 'script', '', 'wa');


const wa = window.wa();
console.log('wa对象', wa);

const ua = wa.getUA();
console.log('ua对象', ua);