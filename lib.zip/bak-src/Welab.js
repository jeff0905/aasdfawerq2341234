/** Welab Analytics */
;(function(window, document, s, u, wa) {

  window['WelabAnalyticsObject2018'] = wa;
  window[wa] = window[wa] || function () {
    /**
     * 0. 环境预处理.
     *    - 1: ajax 和 fetch 的代理. 
     */
    const preProcess = function() {
      hookXhr();
      hookFetch();
    }();

    // 1. 检查Cookie的mark_id, 有则继续后续步骤, 无则种Cookie[x_mark_id].
    Cookie();

    // . 获取browser, os, engine等信息.
    const getUA = function () {
      return UA;
    }

    // 2. track.
    const track = new Track();
    track.init();

    const performance = Util.getPerformance();
    console.log('performance', performance);
    
    return {
      getUA,
    }
  }
})(window, document, 'script', '', 'wa');
