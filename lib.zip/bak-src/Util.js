/**
 * 工具类.
 * 
 * 
 */

const Util = {
  event: {
    // 添加事件.
    on: function (element, event, handler, useCapture = false) {
      if (element.addEventListener) {
        element.addEventListener(event, handler, useCapture);
      } else if (element.attachEvent) {
        element.attachEvent(`on${event}`, handler);
      } else {
        element[`on${event}`] = handler;
      }
    },

    // 移除事件.
    off: function (element, event, handler, useCapture = false) {
      if (element.removeEventListener) {
        element.removeEventListener(event, handler, useCapture);
      } else if (element.detachEvent) {
        element.detachEvent(`on${event}`, handler);
      } else {
        element[`on${event}`] = null;
      }
    },

    // dom ready.
    ready: function (fn) {
      if (document.readyState !== 'loading') {
        fn();
      } else if (window.addEventListener) {
        // window.addEventListener('load', fn);
        window.addEventListener('DOMContentLoaded', fn);
      } else {
        window.attachEvent('onreadystatechange', function () {
          if (document.readyState != 'loading')
            fn();
        });
      }
    },
    // 阻止默认事件.
    preventDefault: function (event) {
      if (event.preventDefault) {
        event.preventDefault();
      } else {
        event.returnValue = false;
      }
    },

    // 阻止事件流或使用 cancelBubble
    stopPropagation: function () {
      if (event.stopPropagation) {
        event.stopPropagation();
      } else {
        event.cancelBubble = true;
      }
    }
  },
  /**
   * 每个机器给予唯一的值,
   * 规则:
   *   [time]_[random]_[ua]_[width*height]_[domain]_[]
   */
  uuid: function () {
    const uuid_time = function () {
      const d = 1 * new Date();
      let i = 0;
      while (d === 1 * new Date()) {
        i++;
      }
      return new Date().getTime() || d.toString(16) + i.toString(16);
    }

    const uuid_random = function () {
      return Math.random().toString(16).replace('.', '');
    }
    return [uuid_time(), uuid_random()];
  },

  /**
   * Canvas (https://www.browserleaks.com/canvas)
   * 相同的HTML5 Canvas元素绘制操作，在不同操作系统、不同浏览器上，产生的图片内容不完全相同。
   * 在图片格式上，不同浏览器使用了不同的图形处理引擎、不同的图片导出选项、不同的默认压缩级别等。
   * 在像素级别来看，操作系统各自使用了不同的设置和算法来进行抗锯齿和子像素渲染操作。即使相同的绘图操作，产生的图片数据的CRC检验也不相同。
   */
  canvasFinger: function () {
    if (this.isCanvaseSupport) {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const text = 'welab';
      ctx.font = "14px 'Arial'";
      ctx.fillStyle = "#f60";
      ctx.fillRect(125, 1, 62, 20);
      ctx.fillStyle = '#069';
      ctx.fillText(text, 2, 15);
      ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
      ctx.fillText(text, 4, 17);
      const base64 = canvas.toDataURL().replace('data:image/png;base64,', '');
      const bin = atob(base64);
      const crc = this.bin2Hex(bin.slice(-16, -12));
      console.log('crc', crc);
      return crc;
    } else {
      return '';
    }
  },

  bin2Hex: function (s) {
    let i
    let l
    let o = ''
    let n
    s += "";
    for (i = 0, l = s.length; i < l; i++) {
      n = s.charCodeAt(i).toString(16)
      o += n.length < 2 ? '0' + n : n
    }
    return o
  },

  isCanvaseSupport: function () {
    const elem = document.createElement('canvas');
    return !!(elem.getContext && elem.getContext('2d'));
  },

  isFunction: function (obj) {
    return Object.prototype.toString.call(obj) === '[object Function]';
  },

  isString: function (obj) {
    return Object.prototype.toString.call(obj) == '[object String]';
  },

  /**
   * 异步加载Js.
   * 
   */
  loadScripts: function (url, callback) {
    var script = document.createElement('script');
    script.async = true;
    script.src = url;

    var entry = document.getElementsByTagName('script')[0];
    entry.parentNode.insertBefore(script, entry);

    script.onload = script.onreadystatechange = function () {
      var readyState = script.readyState;
      if (!readyState || /complete|loaded/.test(script.readyState)) {
        console.log('加载完成');
        callback();
        script.onload = null;
        script.onreadystatechange = null;
      }
    }
  },

  /**
   * performance.
   * 
   */
  getPerformance: function () {
    // performance timing..
    var performance = window.performance || window.webkitPerformance || window.msPerformance || window.mozPerformance;

    if (performance === undefined) {
      return false;
    }
    var timing = performance.timing;
    var in_per = {
      dns: timing.domainLookupEnd - timing.domainLookupStart, //  DNS 解析耗时
      tcp: timing.connectEnd - timing.connectStart, // TCP 连接耗时
      ttfb: timing.responseStart - timing.requestStart, // 网络请求耗时
      dom: timing.domInteractive - timing.responseEnd, // DOM 解析耗时
      res: timing.loadEventStart - timing.domContentLoadedEventEnd, // 资源加载耗时
      firstbyte: timing.responseStart - timing.domainLookupStart, // 首包时间
      fpt: timing.responseEnd - timing.fetchStart, // 首次渲染时间 / 白屏时间
      tti: timing.domInteractive - timing.fetchStart, // 首次可交互时间
      ready: timing.domContentLoadEventEnd - timing.fetchStart, // HTML 加载完成时间
      load: timing.loadEventStart - timing.fetchStart, // 页面完全加载时间
    }
    console.log('时间', in_per);
    return in_per;
  }
}

export default Util;