/**
 * ajax 请求的方法.
 * 1: 全局设置所有ajax的属性.
 * 2: ajax请求的封装.
 * 
 */
import AjaxHook from './Ajaxhook';

/**
 * ajax 原生的创建方法.
 * 
 */
const xhr = function () {
  if (XMLHttpRequest) {
    return new XMLHttpRequest();
  }
  if (window.ActiveXObject) {
    try {
      return new ActiveXObject('Msxml2.XMLHTTP')
    } catch (d) {
      try {
        return new ActiveXObject('Microsoft.XMLHTTP')
      } catch (d) {}
    }
  }
}

/**
 * 请求封装.
 * 
 * @param {*} param 
 */
const api = function (param) {
  const ajax = xhr();

  if (!param.type) {
    param.type = param.data ? 'POST' : 'GET';
  }

  ajax.onreadystatechange = function () {
    if (ajax.readyState == 4) {
      if (ajax.status >= 200 && ajax.status < 300 || ajax.status  == 304) {
        // param.success(ajax.responseText);
      } else {
        // param.fail(ajax.responseText, g.status);
      }
      ajax.onreadystatechange = null;
      ajax.onload = null;
    }
  }

  ajax.open(param.type, param.url, true);
  ajax.send(param.data || null);
}

/**
 * ajax 代理 withCredentials = true. 如果放在页面顶部首先执行脚本的话, 后续所有的ajax都会带上withCredentials的值.
 * 
 * 注意:
 * 如果跨域的时候, Access-Allow-Origin: * 和withCredentials = true会有冲突, 需要将Acess-Allow-Origin: * 的*改为具体的值, 例如
 * Access-Allow-Origin: a.com
 * 
 */
const hookXhr = function () {
  AjaxHook({
    //hook function
    send:function(arg,xhr){
      xhr.withCredentials = true;
    }
  })
}

/**
 * Fetch API 的代理.
 * 同hookXhr.
 * 
 */
const hookFetch = function () {
  if (window.fetch) {
    const fetchWrapper = window.fetch;
    window.fetch = (function (fetch) {
        return function (url, option) {
          if (!option) {
              option = {};
              option.credentials = 'include';
          } else {
              option.credentials = 'include';
          }
          return fetch(url, option)
        };
    })(window.fetch);
  }
}

export {
  api,
  hookXhr,
  hookFetch,
  xhr,
}